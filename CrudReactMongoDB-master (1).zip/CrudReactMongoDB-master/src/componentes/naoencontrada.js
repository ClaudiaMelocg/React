import React from 'react';

function NaoEncontrada() {
  return (
    <div>Página não encontrada</div>
  );
}

export default NaoEncontrada;